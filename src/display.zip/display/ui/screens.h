#ifndef EEZ_LVGL_UI_SCREENS_H
#define EEZ_LVGL_UI_SCREENS_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _objects_t {
    lv_obj_t *main;
    lv_obj_t *setting;
    lv_obj_t *load_setting;
    lv_obj_t *start_load_page;
    lv_obj_t *data_from_receiver;
    lv_obj_t *data_from_receiver_1;
    lv_obj_t *mode_1;
    lv_obj_t *mode_2;
    lv_obj_t *mode_3;
    lv_obj_t *mode_4;
    lv_obj_t *mode_5;
    lv_obj_t *mode_6;
    lv_obj_t *obj0;
    lv_obj_t *obj1;
    lv_obj_t *obj10;
    lv_obj_t *obj2;
    lv_obj_t *obj3;
    lv_obj_t *obj4;
    lv_obj_t *obj5;
    lv_obj_t *obj6;
    lv_obj_t *obj7;
    lv_obj_t *obj8;
    lv_obj_t *obj9;
    lv_obj_t *panel_load_1;
    lv_obj_t *perentase;
    lv_obj_t *top_bar;
    lv_obj_t *top_bar_1;
    lv_obj_t *top_bar_2;
    lv_obj_t *volume;
} objects_t;

extern objects_t objects;

enum ScreensEnum {
    SCREEN_ID_MAIN = 1,
    SCREEN_ID_SETTING = 2,
    SCREEN_ID_LOAD_SETTING = 3,
    SCREEN_ID_START_LOAD_PAGE = 4,
};

void create_screen_main();
void tick_screen_main();

void create_screen_setting();
void tick_screen_setting();

void create_screen_load_setting();
void tick_screen_load_setting();

void create_screen_start_load_page();
void tick_screen_start_load_page();

void create_screens();
void tick_screen(int screen_index);


#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_SCREENS_H*/